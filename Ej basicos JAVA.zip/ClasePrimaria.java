
public class ClasePrimaria {

	public static void main(String[] args) {
			//enteros
			int entero = 10;
        System.out.println("Entero: " + entero);

        
        
        
	}

}
