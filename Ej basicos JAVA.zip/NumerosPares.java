
public class NumerosPares {

	 public static void main(String[] args) {
	        for (int x = 1; x <= 100; x++) {
	        	
	            if (x % 2 == 0) {
	                System.out.println("par");
	            } else {
	                System.out.println(x);
	            }
	        }
	    }
}
