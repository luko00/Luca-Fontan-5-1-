
public class NumerosPrimos {
	
	public static void main(String[] args) {
        for (int x = 50; x <= 100; x++) {
            if (esPrimo(x)) {
                System.out.println(x + 	" primo");
            } else {
                System.out.print(x + " : ");
                listarDivisores(x);
            }
        }
    }

    // M�todo para verificar si un n�mero es primo
    public static boolean esPrimo(int numero) {
        if (numero <= 1) {
            return false;
        }
        for (int x = 2; x <= Math.sqrt(numero); x++) {
            if (numero % x == 0) {
                return false;
            }
        }
        return true;
    }

    // M�todo para listar los divisores de un n�mero
    public static void listarDivisores(int numero) {
        for (int x = 1; x <= numero; x++) {
            if (numero % x == 0) {
                System.out.print(x + " ");
            }
        }
        System.out.println();
    }
}
