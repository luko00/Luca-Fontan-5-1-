import java.util.Scanner;


public class calculadora {

	public static void main(String[] args) {
	
		  // Crear un objeto Scanner para leer la entrada del usuario
        Scanner scanner = new Scanner(System.in);

        // Pedir al usuario que ingrese el primer número
        System.out.print("Ingrese el primer número: ");
        double num1 = scanner.nextDouble();

        // Pedir al usuario que ingrese el segundo número
        System.out.print("Ingrese el segundo número: ");
        double num2 = scanner.nextDouble();

        // Pedir al usuario que elija una operación
        System.out.print("Ingrese la operación (+, -, *, /): ");
        char operacion = scanner.next().charAt(0);

        // Variable para guardar el resultado
        double resultado = 0;

        // Realizar la operación segun la eleccion del usuario
        switch (operacion) {
            case '+':
                resultado = num1 + num2;
                break;
            case '-':
                resultado = num1 - num2;
                break;
            case '*':
                resultado = num1 * num2;
                break;
            case '/':
                // Comprobar si el segundo número es cero para evitar la división por cero
                if (num2 != 0) {
                    resultado = num1 / num2;
                } else {
                    System.out.println("Error: División por cero no permitida.");
                    return; // Salir del programa si se intenta dividir por cero
                }
                break;
            default:
                System.out.println("Operación no válida.");
                return; // Salir del programa si la operación no es válida
        }

        // Imprimir el resultado de la operación
        System.out.println("El resultado es: " + resultado);

        // Cerrar el objeto Scanner
        scanner.close();
		
		
	}

}
