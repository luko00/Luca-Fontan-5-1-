
import java.util.Scanner; //importas la clase

public class Pedirnumero {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in); //Le creas una variable a la clase
        
        
       int numero;

       do { 	
        System.out.print("Por favor, ingresa un n�mero: ");
        numero = scan.nextInt(); //le asignas el metodo
        if (esPrimo(numero) && numero > 100) {
            System.out.println("�El n�mero " + numero + " es mayor que 100 y primo!");
            break;
        }
    } while (true); 


        scan.close();
       
    }



//M�todo para verificar si un n�mero es primo
public static boolean esPrimo(int numero) {
    if (numero <= 1) {
        return false;
    }
    for (int i = 2; i <= Math.sqrt(numero); i++) {
        if (numero % i == 0) {
            return false;
        }
    }
    return true;
}
}