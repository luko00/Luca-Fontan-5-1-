import java.util.Arrays; //librerira para luego ordenar los nombres alfabeticamente

public class foreach {

    public static void main(String[] args) {
        // Crear una lista de los nombres
        String[] nombres = {"Luca", "Marco", "Matias", "Patricio", "Francisco"};
        
     // Ordenar los nombres en orden alfabético usando la libreria previamente declarada
        Arrays.sort(nombres);
        
        // Usar un bucle for-each para iterar a través de la lista de nombres
        for (String nom : nombres) {
            // Imprimir los nombres
            System.out.println(nom);
        }
    }
}