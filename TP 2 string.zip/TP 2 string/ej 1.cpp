#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(){
	
	char nombre[20];
	
	printf("Ingrese su nombre:\n");
	scanf("%s",&nombre);
	
	printf("Su nombre es: %s",nombre);
	
}
