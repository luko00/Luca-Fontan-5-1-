#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(){
	
	char cadena[30];
	int longitud,y,contpalin=0;
	
	printf("Ingrese una palabra para saber si es palindromo:\n");
	scanf("%s",&cadena);
	
	longitud = strlen(cadena);
	
	for(y=longitud-1;cadena[y]==cadena[contpalin]&&y>=0;y--){
	
	contpalin++;
	
	}
	
	if(contpalin==longitud){
		
	printf("Es palindromo");
		
	}else{
		
	printf("No es palindromo");
		
	}

	
}
