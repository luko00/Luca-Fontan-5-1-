#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int main(){
	
	char cadena[100], char1, char2;
	int x,longitud;
	
	printf("Ingrese una cadena de caracteres:\n");
	fgets(cadena, sizeof(cadena), stdin);
	
	printf("Ingrese el caracter para ser reemplazado\n");
	scanf(" %c",&char1);
	
	printf("Ingrese el caracter para reemplazar\n");
	scanf(" %c",&char2);
	
	longitud = strlen(cadena);
	
	for(x=0;x<=longitud;x++){
		
	if(cadena[x]==char1){
		
		cadena[x]=char2;
	}	
}
	
	printf("%s",cadena);	
}
