#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(){
	
	char cadena1[20], cadena2[20], aux;
	int longitud1,longitud2,x,y, resultado;
	
	printf("Ingrese su primer cadena de caracteres:\n");
	scanf("%s",&cadena1);
	
	printf("Ingrese su segunda cadena de caracteres:\n");
	scanf("%s",&cadena2);
	
	longitud1 = strlen(cadena1);
	longitud2 = strlen(cadena2);
	
	if(longitud1==longitud2){
	
	for(x=0;x<longitud1-1;x++){
		
		for(y=0;y<longitud1-x-1;y++){
		
		if(cadena1[y] > cadena1[y+1]){
			
		aux = cadena1[y];	
		cadena1[y] = cadena1[y+1];	
		cadena1[y+1] = aux;	
		}		
		}
	}
	for(x=0;x<longitud2-1;x++){	
	for(y=0;y<longitud2-x-1;y++){
		
		if(cadena2[y] > cadena2[y+1]){
			
		aux = cadena2[y];	
		cadena2[y] = cadena2[y+1];	
		cadena2[y+1] = aux;	
		}		
		}
	}
	resultado = strcmp(cadena1, cadena2);
	if(resultado==0){	
	printf("Es un anagrama");		
	}else{	
	printf("No es un anagrama");	
	}	
	}else{	
	printf("No es un anagrama");	
	}
}
