#include <stdio.h>
#include <string.h>

#define max_longitud_pal 100

void encontrar_porcion_repetida_mas_larga(char palabras[5][max_longitud_pal], char resultado[max_longitud_pal]) {
    int x, y, z;
    char porcion_repetida[max_longitud_pal] = "";
    int max_longitud = 0;

    // Iterar sobre todas las posibles subcadenas de la primera palabra
    for (x = 0; x < strlen(palabras[0]); x++) {
        for (y = x + 1; y <= strlen(palabras[0]); y++) {
            char subcadena[max_longitud_pal];
            strncpy(subcadena, palabras[0] + x, y - x);
            subcadena[y - x] = '\0';
            int repeticiones = 0;

            // Verificar si la subcadena se repite en al menos una de las otras palabras
            for (z = 1; z < 5; z++) {
                char *ptr = strstr(palabras[z], subcadena);
                if (ptr != NULL) {
                    repeticiones = 1;
                    break;
                }
            }

            // Si la subcadena se repite en al menos una de las otras palabras
            if (repeticiones && (y - x) > max_longitud) {
                strcpy(porcion_repetida, subcadena);
                max_longitud = y - x;
            }
        }
    }

    if (max_longitud > 0) {
        strcpy(resultado, porcion_repetida);
    } else {
        strcpy(resultado, "Ninguna");
    }
}

int main() {
    char palabras[5][max_longitud_pal];
    char porcion_repetida_mas_larga[max_longitud_pal];
    int x;

    // Solicitar al usuario que ingrese 5 palabras
    printf("Ingrese 5 palabras:\n");
    for (x = 0; x < 5; x++) {
        printf("- ");
        scanf("%s", palabras[x]);
    }

    // Encontrar la porci�n repetida m�s larga
    encontrar_porcion_repetida_mas_larga(palabras, porcion_repetida_mas_larga);

    // Mostrar la porci�n repetida m�s larga
    if (strcmp(porcion_repetida_mas_larga, "Ninguna") == 0) {
        printf("No hay porcion de palabra repetida mas larga.\n");
    } else {
        printf("La porcion de palabra repetida mas larga es: %s\n", porcion_repetida_mas_larga);
    }

    return 0;
}
