#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(){
	
	char cadena[100];
	int x, longitud, vocales=0;
	
	printf("Ingrese una cadena de caracteres para averiguar la cantidad de vocales:\n");
	fgets(cadena, sizeof(cadena), stdin);
	
	longitud = strlen(cadena);
	
	for(x=0;x<=longitud;x++){
		
		if(cadena[x]=='a'||cadena[x]=='A'||cadena[x]=='e'||cadena[x]=='E'||cadena[x]=='i'||cadena[x]=='I'||cadena[x]=='o'||cadena[x]=='O'||cadena[x]=='u'||cadena[x]=='U'){
			
		vocales++;
			
		}
		
		
		
	}
	
	printf("La cantidad de vocales es:%d",vocales);
	
	
	
}
