/*Realizar un programa que realice las siguientes acciones
a. Guarde el registro del nombre y el puntaje de un jugador (solicitando el ingreso
de los datos del usuario)
b. Muestre el resultado de los 10 mejores jugadores ordenados por mayor
puntaje.
c. Realice y muestre una b�squeda de un Nombre y devuelva sus resultados
NOTA: el registro debe permanecer aunque se apague la PC.*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Persona {
    char nombre[50];
    int calificacion;
};

// Funci�n para ingresar datos de una persona
void ingresarDatos(struct Persona *persona) {
    printf("Ingrese el nombre: ");
    scanf("%s", persona->nombre);
    printf("Ingrese el puntaje de su calificacion: ");
    scanf("%d", &persona->calificacion);
}

void guardarDatos(struct Persona persona) {
    FILE *archivo;
    archivo = fopen("ficheros5.txt", "a");
    if (archivo == NULL) {
        printf("Error al abrir el archivo.\n");
        return;
    }
    fprintf(archivo, "%s %d\n", persona.nombre, persona.calificacion);
    fclose(archivo);
    printf("Datos guardados correctamente.\n");
}

void buscarNombre( char nombre[]) {
    FILE *archivo;
    archivo = fopen("ficheros5.txt", "r");
    if (archivo == NULL) {
        printf("Error al abrir el archivo.\n");
        return;
    }
    struct Persona persona;
    int encontrado = 0;
    while (fscanf(archivo, "%s %d\n", persona.nombre, &persona.calificacion) != EOF) {
        if (strcmp(persona.nombre, nombre) == 0) {
            printf("Persona encontrada:\n");
            printf("Nombre: %s\n", persona.nombre);
            printf("Calificacion: %d\n", persona.calificacion);
            encontrado = 1;
            system("PAUSE");
            system("CLS");
            break;
        }
    }
    if (!encontrado) {
        printf("Persona no encontrada.\n");
    }
    fclose(archivo);
}

int compararpuntaje(const void *a, const void *b) {
    return (*(struct Persona*)a).calificacion - (*(struct Persona*)b).calificacion;
}

void mostrarMejoresJugadores() {
    struct Persona jugadores[100]; // Suponemos que hay un m�ximo de 100 jugadores en el archivo
    int contador = 0;

    FILE *archivo = fopen("ficheros5.txt", "r");
    if (archivo == NULL) {
        printf("No hay jugadores registrados todav�a.\n");
        return;
    }

    // Leer los datos de los jugadores desde el archivo
    while (fscanf(archivo, "%s %d\n", jugadores[contador].nombre, &jugadores[contador].calificacion) != EOF) {
        contador++;
    }
    fclose(archivo);

    // Ordenar los jugadores por puntaje
    qsort(jugadores, contador, sizeof(struct Persona), compararpuntaje);

    // Mostrar los 10 mejores jugadores
    printf("Los 10 mejores jugadores:\n");
    for (int i = contador - 1; i >= contador - 10 && i >= 0; i--) {
        printf("%s - %d\n", jugadores[i].nombre, jugadores[i].calificacion);
    }
}


int main() {
    int opcion;
    char nombre[50];
    struct Persona persona;
    
    do {
        printf("Menu:\n");
        printf("1. Ingresar datos\n");
        printf("2. Mostrar los 10 mejores jugadores\n");
        printf("3. Buscar nombre\n");
        printf("4. Salir\n");
        printf("Seleccione una opcion: ");
        scanf("%d", &opcion);
        
        switch (opcion) {
            case 1:
			system("CLS");
                ingresarDatos(&persona);
                guardarDatos(persona);
                system("PAUSE");
			system("CLS");
                break;
            case 2:
            	system("CLS");
                mostrarMejoresJugadores();
                system("PAUSE");
			system("CLS");
                break;
            case 3:
            	system("CLS");
                printf("Ingrese el Nombre a buscar: ");
                scanf("%s", nombre);
                buscarNombre(nombre);
                system("PAUSE");
			system("CLS");
                break;
            case 4:
            	system("CLS");
                printf("Saliendo del programa.\n");
                system("PAUSE");
                system("CLS");
			break;    
            default:
            	system("CLS");
                printf("Opcion invalida.\n");
                system("PAUSE");
			system("CLS");
                break;
        }
    } while (opcion != 4);
    
    return 0;
}
