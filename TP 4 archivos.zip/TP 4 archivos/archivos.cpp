/*1) Realizar un programa en el cual se ingresen los siguientes datos
Nombre, Apellido y DNI
a) Crear un menu donde se ingresen los datos y los guarde en un
archivo
b) Otro �tem donde se pueda realizar una b�squeda por DNI y
devuelva los datos de Nombre y apellido
c) Salir del mismo*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Persona {
    char nombre[50];
    char apellido[50];
    int dni;
};

// Funci�n para ingresar datos de una persona
void ingresarDatos(struct Persona *persona) {
    printf("Ingrese el nombre: ");
    scanf("%s", persona->nombre);
    printf("Ingrese el apellido: ");
    scanf("%s", persona->apellido);
    printf("Ingrese el DNI: ");
    scanf("%d", &persona->dni);
}

// Funci�n para guardar datos en un archivo
void guardarDatos(struct Persona persona) {
    FILE *archivo;
    archivo = fopen("ficheros.txt", "a");
    if (archivo == NULL) {
        printf("Error al abrir el archivo.\n");
        return;
    }
    fprintf(archivo, "%s %s %d\n", persona.nombre, persona.apellido, persona.dni);
    fclose(archivo);
    printf("Datos guardados correctamente.\n");
}

// Funci�n para buscar una persona por DNI
void buscarPorDNI(int dni) {
    FILE *archivo;
    archivo = fopen("ficheros.txt", "r");
    if (archivo == NULL) {
        printf("Error al abrir el archivo.\n");
        return;
    }
    struct Persona persona;
    int encontrado = 0;
    while (fscanf(archivo, "%s %s %d\n", persona.nombre, persona.apellido, &persona.dni) != EOF) {
        if (persona.dni == dni) {
            printf("Persona encontrada:\n");
            printf("Nombre: %s\n", persona.nombre);
            printf("Apellido: %s\n", persona.apellido);
            encontrado = 1;
            system("PAUSE");
			system("CLS");
            break;
        }
    }
    if (!encontrado) {
        printf("Persona no encontrada.\n");
    }
    fclose(archivo);
}

int main() {
    int opcion, dni;
    struct Persona persona;
    
    do {
        printf("\nMenu:\n");
        printf("1. Ingresar datos\n");
        printf("2. Buscar por DNI\n");
        printf("3. Salir\n");
        printf("Seleccione una opcion: ");
        scanf("%d", &opcion);
        
        switch (opcion) {
            case 1:
			system("CLS");
                ingresarDatos(&persona);
                guardarDatos(persona);
                system("PAUSE");
			system("CLS");
                break;
            case 2:
            	system("CLS");
                printf("Ingrese el DNI a buscar: ");
                scanf("%d", &dni);
                buscarPorDNI(dni);
                system("PAUSE");
			system("CLS");
                break;
            case 3:
            	system("CLS");
                printf("Saliendo del programa.\n");
                system("PAUSE");
			system("CLS");
                break;
            default:
            	system("CLS");
                printf("Opcion invalida.\n");
                system("PAUSE");
			system("CLS");
                break;
        }
    } while (opcion != 3);
    
    return 0;
}

