/*Agregarle validaci�n de datos de manera que no se repitan cuando
sea necesario.*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Persona {
    char nombre[50];
    char apellido[50];
    int dni;
};

int dniExistente(int dni) {
    FILE *archivo;
    archivo = fopen("ficheros3.txt", "r");
    if (archivo == NULL) {
        printf("Error al abrir el archivo.\n");
        return 0;
    }
    struct Persona persona;
    while (fscanf(archivo, "%s %s %d\n", persona.nombre, persona.apellido, &persona.dni) != EOF) {
        if (persona.dni == dni) {
            fclose(archivo);
            return 1; // DNI encontrado
        }
    }
    fclose(archivo);
    return 0; // DNI no encontrado
}


// Funci�n para ingresar datos de una persona
void ingresarDatos(struct Persona *persona) {
    printf("Ingrese el nombre: ");
    scanf("%s", (*persona).nombre);
    printf("Ingrese el apellido: ");
    scanf("%s", (*persona).apellido);
    
    do {
        printf("Ingrese el DNI: ");
        scanf("%d", &persona->dni);
        if (dniExistente(persona->dni)) {
            printf("El DNI ingresado ya existe. Por favor, ingrese otro DNI.\n");
        }
    } while (dniExistente(persona->dni));
}

// Funci�n para guardar datos en un archivo
void guardarDatos(struct Persona persona) {
    FILE *archivo;
    archivo = fopen("ficheros3.txt", "a");
    if (archivo == NULL) {
        printf("Error al abrir el archivo.\n");
        return;
    }
    fprintf(archivo, "%s %s %d\n", persona.nombre, persona.apellido, persona.dni);
    fclose(archivo);
    printf("Datos guardados correctamente.\n");
}

// Funci�n para buscar una persona por DNI
void buscarPorDNI(int dni) {
    FILE *archivo;
    archivo = fopen("ficheros3.txt", "r");
    if (archivo == NULL) {
        printf("Error al abrir el archivo.\n");
        return;
    }
    struct Persona persona;
    int encontrado = 0;
    while (fscanf(archivo, "%s %s %d\n", persona.nombre, persona.apellido, &persona.dni) != EOF) {
        if (persona.dni == dni) {
            printf("Persona encontrada:\n");
            printf("Nombre: %s\n", persona.nombre);
            printf("Apellido: %s\n", persona.apellido);
            encontrado = 1;
            system("PAUSE");
            system("CLS");
            break;
        }
    }
    if (!encontrado) {
        printf("Persona no encontrada.\n");
    }
    fclose(archivo);
}

// Funci�n para buscar una persona por Apellido y Nombre
void buscarPorApellidoNombre(char apellido[], char nombre[]) {
    FILE *archivo;
    archivo = fopen("ficheros3.txt", "r");
    if (archivo == NULL) {
        printf("Error al abrir el archivo.\n");
        return;
    }
    struct Persona persona;
    int encontrado = 0;
    while (fscanf(archivo, "%s %s %d\n", persona.nombre, persona.apellido, &persona.dni) != EOF) {
        if (strcmp(persona.apellido, apellido) == 0 && strcmp(persona.nombre, nombre) == 0) {
            printf("Persona encontrada:\n");
            printf("Nombre: %s\n", persona.nombre);
            printf("Apellido: %s\n", persona.apellido);
            printf("DNI: %d\n", persona.dni);
            encontrado = 1;
            system("PAUSE");
            system("CLS");
            break;
        }
    }
    if (!encontrado) {
        printf("Persona no encontrada.\n");
    }
    fclose(archivo);
}

int main() {
    int opcion, dni;
    char nombre[50], apellido[50];
    struct Persona persona;
    
    do {
        printf("\nMenu:\n");
        printf("1. Ingresar datos\n");
        printf("2. Buscar por DNI\n");
        printf("3. Buscar por Apellido y Nombre\n");
        printf("4. Salir\n");
        printf("Seleccione una opcion: ");
        scanf("%d", &opcion);
        
        switch (opcion) {
            case 1:
                system("CLS");
                ingresarDatos(&persona);
                guardarDatos(persona);
                system("PAUSE");
                system("CLS");
                break;
            case 2:
                system("CLS");
                printf("Ingrese el DNI a buscar: ");
                scanf("%d", &dni);
                buscarPorDNI(dni);
                system("PAUSE");
                system("CLS");
                break;
            case 3:
                system("CLS");
                printf("Ingrese el Apellido a buscar: ");
                scanf("%s", apellido);
                printf("Ingrese el Nombre a buscar: ");
                scanf("%s", nombre);
                buscarPorApellidoNombre(apellido, nombre);
                system("PAUSE");
                system("CLS");
                break;
            case 4:
                system("CLS");
                printf("Saliendo del programa.\n");
                system("PAUSE");
                system("CLS");
                break;
            default:
                system("CLS");
                printf("Opcion invalida.\n");
                system("PAUSE");
                system("CLS");
                break;
        }
    } while (opcion != 4);
    
    return 0;
}
