/*Intercambiar el valor de dos variables usando punteros y funciones.
Mostrando los valores iniciales y valores finales.*/

#include <stdio.h>

void intercambio(int *a, int *b){
	
	int aux = *a;
	*a = *b;
	*b = aux;
	
}


int main(){
	
	int num1,num2;
	
	printf("Ingrese el valor del primer numero:");
	scanf("%d",&num1);
	
	printf("Ingrese el valor del segundo numero:");
	scanf("%d",&num2);
	
	printf("Antes del intercambio: x=%d,    y=%d  \n", num1, num2);
	
	intercambio(&num1, &num2);
	
	printf("Despues del intercambio: x=%d,    y=%d  \n",num1, num2);
	return 0;
	
}
