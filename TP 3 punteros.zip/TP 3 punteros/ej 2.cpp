/*Encontrar la suma y el promedio de los elementos de un arreglo usando
punteros y funciones.*/
#include <stdio.h>

int suma(int vector[], int dim);

float promedio(int vector[], int dim);

int main(){
	int dim=0;
	int vector[dim];
	int x;
	
	printf("Ingrese con la cantidad de numeros que quiera trabajar\n");
	scanf("%d",&dim);
	
	for(x=0;x<dim;x++){
		
	printf("Ingrese el valor del numero %d:\n",x+1);
	scanf("%d",&vector[x]);	
	}
	
	printf("La suma de todos los numeros es:%d\n",suma(vector,dim));
	printf("El promedio de todos los numeros es:%f\n",promedio(vector,dim));
}

int suma(int vector[], int dim){
	int x;
	int suma=0;
	for(x=0;x<dim;x++){	
	suma += vector[x];	
}
	return suma;
}

float promedio(int vector[], int dim){
	int x;
	float promedio=0;
	for(x=0;x<dim;x++){	
	promedio += vector[x];	
}
promedio = promedio/dim;
	return promedio;
}

