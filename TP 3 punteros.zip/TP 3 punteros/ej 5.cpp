/* Concatenar dos cadenas usando punteros y funciones.*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char cadena1[100];
char cadena2[100];

void concatenar(char *cadena1, char *cadena2);

int main(){
	printf("Ingrese la primer cadena de caracteres:\n");
	fgets(cadena1, sizeof(cadena1), stdin);
	cadena1[strcspn(cadena1, "\n")] = '\0';
	
	printf("Ingrese la segunda cadena de caracteres:\n");
	fgets(cadena2, sizeof(cadena2), stdin);
	cadena1[strcspn(cadena2, "\n")] = '\0';
	
concatenar(cadena1, cadena2);	
	
	printf("La cadena concatenada es:%s", cadena1);
	
}

void concatenar(char *cadena1, char *cadena2){
	
	strcat(cadena1, cadena2);
	
}
