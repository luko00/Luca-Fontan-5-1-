/*3. Encontrar el mayor y el menor elemento de un arreglo usando punteros y
funciones.*/
#include <stdio.h>

int may, men;

void busqueda(int *vec, int dim, int *may, int *men);


int main(){
	int dim=0;
	int vec[dim];
	int x;
	
	printf("Ingrese con la cantidad de numeros que quiera trabajar\n");
	scanf("%d",&dim);
	
	for(x=0;x<dim;x++){
		
	printf("Ingrese el valor del numero %d:\n",x+1);
	scanf("%d",&vec[x]);	
		
	}
	
	
	busqueda(vec, dim, &may, &men);
	
	printf("El numero mayor es:%d\n",may);
	printf("El numero menor es:%d\n",men);
	return 0;
}


void busqueda(int *vec, int dim, int *may, int *men){
	int x;
	*may = *men = *vec;
	for(x=1;x<dim;x++){
		if(*(vec+x) > *may){
		*may = *(vec+x);		
		}
		if(*(vec+x) < *men){
			*men = *(vec+x);
		}		
	}	
}
