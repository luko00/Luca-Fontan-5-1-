/* Copiar un arreglo en otro arreglo usando punteros y funciones. Mostrando
el resultado final.*/

#include <stdio.h>

void copiar(int *vec, int *vec2, int dim);

int main(){
	int dim=0;
	int vec[dim];
	int vec2[dim];
	int x;

	printf("Ingrese con la cantidad de numeros que quiera trabajar\n");
	scanf("%d",&dim);
	
	for(x=0;x<dim;x++){
		
	printf("Ingrese el valor del numero %d:\n",x+1);
	scanf("%d",&vec[x]);	
		
	}
	
	copiar(vec, vec2, dim);
	
	printf("El segundo arreglo es:");
	for(x=0;x<dim;x++){
		printf("%d",vec2[x]);
	}
	
	return 0;
}


void copiar(int *vec, int *vec2, int dim){
	int x;
	for(x=0;x<dim;x++){
	*(vec2+x) = *(vec+x);	
	}
}
