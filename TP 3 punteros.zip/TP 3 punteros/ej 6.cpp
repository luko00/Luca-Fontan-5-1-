/*Contar el n�mero de ocurrencias de un elemento en un arreglo usando
puntero y funciones*/
#include <stdio.h>

void contar(int *vec, int dim, int num,int *cont);

int main(){
	int dim=0;
	int x;
	int num;
	int cont;
	
	printf("Ingrese con la cantidad de numeros que quiera trabajar\n");
	scanf("%d",&dim);
	
	int vec[dim];
	
	for(x=0;x<dim;x++){
		
	printf("Ingrese el valor del numero %d:\n",x+1);
	scanf("%d",&vec[x]);	
		
	}
	printf("\nEliga el elemento a buscar en el array:\n");
	scanf("%d",&num);
	printf("\n");
	
	contar(vec, dim, num, &cont);
	
	for(x=0;x<dim;x++){
		printf("%d",vec[x]);
	}
	printf("\n\nLa cantidad de veces que aparece el numero %d en este array es:%d",num, cont);
}

void contar(int *vec, int dim, int num, int *cont){
	int x;
	for(x=0;x<dim;x++){	
	if(*(vec+x)==num){
	(*cont)++;	
	}	
	}
}
	
	
	
	

