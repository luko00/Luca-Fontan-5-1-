import javax.swing.*;
import java.awt.*;

public class Nivel1 extends JFrame {
    private Jugador jugador;
    private JPanel contentPane;
    private Enemigos2 enemigos; // Definir enemigos como una variable de instancia
    private JLabel lblVidas;
    private boolean levelCompleted = false;
    private JLabel lblNivel;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                Nivel1 frame = new Nivel1();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Nivel1() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(350, 50, 700, 700);
        contentPane = new JPanel();
        contentPane.setBackground(Color.BLACK);
        contentPane.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Inicializar enemigos
        int bottomLimit = 574;
        enemigos = new Enemigos2(contentPane, bottomLimit, this); // Asignar a la variable de instancia

        // Inicializar el jugador con la referencia a los enemigos
        jugador = new Jugador(this, enemigos);

        // Inicializar vidas
        lblVidas = new JLabel("Lives: " + Juego.getVidas());
        lblVidas.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblVidas.setForeground(Color.WHITE);
        lblVidas.setBounds(10, 620, 100, 30);
        contentPane.add(lblVidas);

        lblNivel = new JLabel("Level 1");
        lblNivel.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblNivel.setForeground(Color.WHITE);
        lblNivel.setBounds(600, 620, 100, 30);
        contentPane.add(lblNivel);
        
        JButton btnNewButton = new JButton("");
        btnNewButton.setEnabled(false);
        btnNewButton.setForeground(Color.RED);
        btnNewButton.setBackground(Color.RED);
        btnNewButton.setBounds(0, bottomLimit, 684, 8);
        contentPane.add(btnNewButton);
    }

    public Jugador getJugador() {
        return jugador;
    }

    public void loseLife() {
        Juego.setVidas(Juego.getVidas() - 1);
        lblVidas.setText("Lives: " + Juego.getVidas());
        if (Juego.getVidas() <= 0) {
            gameOver();
        }
    }
 
    private void gameOver() {
        // Detener cualquier lógica que pueda estar ejecutándose en los enemigos o jugador

        // Mostrar el mensaje de Game Over
        JOptionPane.showMessageDialog(this, "Game Over", "Game Over", JOptionPane.INFORMATION_MESSAGE);

        Juego.setVidas(3);
        // Opciones después del Game Over
        int option = JOptionPane.showOptionDialog(this,
            "¿Deseas volver al menú o salir del juego?",
            "Fin del juego",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            new Object[]{"Volver al Menú", "Salir"},
            "Volver al Menú");

        if (option == JOptionPane.YES_OPTION) {
            volverAlMenu();
            
        } else {
            System.exit(0);
            
        }
        
    }

    private void volverAlMenu() {
        // Ocultar el nivel actual y mostrar el menú principal
        this.dispose(); // Cierra la ventana actual

        Fondo menu = new Fondo(); // Asumiendo que Fondo es la clase del menú
        menu.setVisible(true); // Mostrar el menú principal
    }

    public void checkLevelComplete() {
        if (!levelCompleted && enemigos.allEnemiesRemoved()) { // Ahora enemigos está disponible
            levelCompleted = true; // Asegúrate de que solo se abra una vez
            // Cambiar a Nivel2
            this.dispose(); // Cierra el nivel 1
            java.awt.EventQueue.invokeLater(() -> {
                Nivel2 nivel2 = new Nivel2();
                nivel2.setVisible(true);
            });
        }
    }
}
