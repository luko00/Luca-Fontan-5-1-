import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class Enemigos3 {
    private static final int PANEL_SIZE = 31; // Tama�o del enemigo
    private static final int NUM_ENEMIES_PER_ROW = 10; // N�mero de enemigos por fila
    private static final int NUM_ROWS = 4; // N�mero de filas de enemigos
    private static final int MOVE_STEP = 1; // Paso de movimiento horizontal
    private static final int TIMER_DELAY = 15; // Retraso del temporizador en milisegundos
    private static final int MOVE_DOWN_STEP = 20; // Paso de movimiento vertical
    private static final int HORIZONTAL_GAP = 20; // Espacio horizontal entre enemigos
    private static final int VERTICAL_GAP = 20; // Espacio vertical entre enemigos
    private static final int BULLET_DELAY = 1000; // Retraso para disparos enemigos en milisegundos
    private static final int BULLET_MOVE_STEP = 5; // Paso de movimiento de la bala
    private static final int BULLET_MOVE_INTERVAL = 10; // Intervalo de actualizaci�n de las balas en milisegundos

    private JPanel[][] enemyPanels = new JPanel[NUM_ROWS][NUM_ENEMIES_PER_ROW];
    private int direction = 1;
    private boolean hitLeftEdge = false;
    private boolean hitRightEdge = false;
    private Timer movementTimer; 
    private Timer shootingTimer;
    private Timer bulletMovementTimer;
    private JPanel parentPanel;
    private int bottomLimit; // L�mite inferior para el movimiento de los enemigos
    private Nivel2 nivel2; // Referencia al nivel para manejar la p�rdida de vida
    private Image enemyImage;
    private List<JPanel> enemyBullets = new ArrayList<>();

    public Enemigos3(JPanel parent, int bottomLimit) {
        this.parentPanel = parent;
        this.bottomLimit = bottomLimit;
        this.nivel2 = (Nivel2) SwingUtilities.getWindowAncestor(parent); // Obtener referencia a Nivel2
        this.enemyImage = new ImageIcon("enemies.png").getImage(); // Cargar imagen del enemigo
        initializeEnemies();
        startMovement();
        startShooting();
        startBulletMovement();
    }

    private void initializeEnemies() {
        for (int row = 0; row < NUM_ROWS; row++) {
            for (int col = 0; col < NUM_ENEMIES_PER_ROW; col++) {
                JPanel panel = new JPanel() {
                    @Override
                    protected void paintComponent(Graphics g) {
                        super.paintComponent(g);
                        g.drawImage(enemyImage, 0, 0, PANEL_SIZE, PANEL_SIZE, this); // Dibujar la imagen del enemigo
                    }
                };
                panel.setBackground(Color.BLACK); // Establecer el fondo a negro
                panel.setBounds(
                    63 + col * (PANEL_SIZE + HORIZONTAL_GAP),
                    11 + row * (PANEL_SIZE + VERTICAL_GAP),
                    PANEL_SIZE, PANEL_SIZE
                );
                parentPanel.add(panel);
                enemyPanels[row][col] = panel;
            }
        }
    }

    private void startMovement() {
        movementTimer = new Timer();
        movementTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                SwingUtilities.invokeLater(() -> moveEnemies());
            }
        }, 0, TIMER_DELAY);
    }

    private void startShooting() {
        shootingTimer = new Timer();
        shootingTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                SwingUtilities.invokeLater(() -> shoot());
            }
        }, 0, BULLET_DELAY);
    }

    private void startBulletMovement() {
        bulletMovementTimer = new Timer();
        bulletMovementTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                SwingUtilities.invokeLater(() -> moveBullets());
            }
        }, 0, BULLET_MOVE_INTERVAL); // Aumentar el intervalo para ralentizar el movimiento
    }

    private void moveEnemies() {
        hitLeftEdge = false;
        hitRightEdge = false;

        for (int row = 0; row < NUM_ROWS; row++) {
            for (int col = 0; col < NUM_ENEMIES_PER_ROW; col++) {
                JPanel panel = enemyPanels[row][col];
                if (panel != null) {
                    if (panel.getX() <= 0) {
                        hitLeftEdge = true;
                    }
                    if (panel.getX() + PANEL_SIZE >= parentPanel.getWidth()) {
                        hitRightEdge = true;
                    }
                }
            }
        }

        if (hitLeftEdge) {
            direction = 1;
            moveDown();
        } else if (hitRightEdge) {
            direction = -1;
            moveDown();
        }

        for (int row = 0; row < NUM_ROWS; row++) {
            for (int col = 0; col < NUM_ENEMIES_PER_ROW; col++) {
                JPanel panel = enemyPanels[row][col];
                if (panel != null) {
                    int newX = panel.getX() + MOVE_STEP * direction;
                    if (newX >= 0 && newX + PANEL_SIZE <= parentPanel.getWidth()) {
                        panel.setLocation(newX, panel.getY());
                    }
                }
            }
        }
    }

    private void moveDown() {
        for (int row = 0; row < NUM_ROWS; row++) {
            for (int col = 0; col < NUM_ENEMIES_PER_ROW; col++) {
                JPanel panel = enemyPanels[row][col];
                if (panel != null) {
                    int newY = panel.getY() + MOVE_DOWN_STEP;
                    if (newY >= bottomLimit - 10) {
                        // Notificar al Nivel2 sobre la p�rdida de vida
                        nivel2.loseLife();
                        newY = 11; // Resetear a la parte superior si alcanza el l�mite
                    }
                    panel.setLocation(panel.getX(), newY);
                }
            }
        }
    }

    private void shoot() {
        Random rand = new Random();
        int row = rand.nextInt(NUM_ROWS);
        int col = rand.nextInt(NUM_ENEMIES_PER_ROW);
        JPanel enemy = enemyPanels[row][col];

        if (enemy != null) {
            int x = enemy.getX() + PANEL_SIZE / 2 - 2; // Centrar el disparo
            int y = enemy.getY() + PANEL_SIZE; // Disparar desde la parte inferior del enemigo

            JPanel bullet = new JPanel();
            bullet.setBackground(Color.GREEN);
            bullet.setOpaque(true);
            bullet.setBounds(x, y, 4, 10); // Tama�o de la bala

            parentPanel.add(bullet);
            enemyBullets.add(bullet);
        }
    }

    private void moveBullets() {
        List<JPanel> toRemoveBullets = new ArrayList<>();
        for (JPanel bullet : enemyBullets) {
            bullet.setLocation(bullet.getX(), bullet.getY() + BULLET_MOVE_STEP); // Mover la bala hacia abajo
            if (bullet.getY() > parentPanel.getHeight() || checkBulletCollisionWithPlayer(bullet)) {
                toRemoveBullets.add(bullet);
                parentPanel.remove(bullet);
            }
        }
        enemyBullets.removeAll(toRemoveBullets);
    }

    private boolean checkBulletCollisionWithPlayer(JPanel bullet) {
        Rectangle bulletBounds = bullet.getBounds();
        Component[] components = parentPanel.getComponents();
        for (Component component : components) {
            if (component instanceof Jugador2) {
                Jugador2 player = (Jugador2) component;
                Rectangle playerBounds = player.getBounds();
                if (bulletBounds.intersects(playerBounds)) {
                    nivel2.loseLife(); // Restar vida al jugador
                    return true; // Colisi�n detectada
                }
            }
        }
        return false;
    }

    public JPanel getEnemy(int row, int col) {
        if (row >= 0 && row < NUM_ROWS && col >= 0 && col < NUM_ENEMIES_PER_ROW) {
            return enemyPanels[row][col];
        }
        return null;
    }

    public int getNumRows() {
        return NUM_ROWS;
    }

    public int getNumEnemiesPerRow() {
        return NUM_ENEMIES_PER_ROW;
    }

    public void removeEnemy(int row, int col) {
        if (row >= 0 && row < NUM_ROWS && col >= 0 && col < NUM_ENEMIES_PER_ROW) {
            JPanel enemy = enemyPanels[row][col];
            if (enemy != null) {
                parentPanel.remove(enemy);
                enemyPanels[row][col] = null; // Marcar como eliminado
                parentPanel.repaint();
            }
        }
    }
    public boolean allEnemiesRemoved() {
        for (int row = 0; row < NUM_ROWS; row++) {
            for (int col = 0; col < NUM_ENEMIES_PER_ROW; col++) {
                if (enemyPanels[row][col] != null) {
                    return false; // Hay enemigos restantes
                }
            }
        }
        return true; // Todos los enemigos han sido eliminados
    }
    public void stopTimers() {
        if (movementTimer != null) {
            movementTimer.cancel();
        }
        if (shootingTimer != null) {
            shootingTimer.cancel();
        }
        if (bulletMovementTimer != null) {
            bulletMovementTimer.cancel();
        }
    }
}
