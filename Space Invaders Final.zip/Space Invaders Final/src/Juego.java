public class Juego {
    private static int vidas = 3;

    public static int getVidas() {
        return vidas;
    }

    public static void setVidas(int vidas) {
        Juego.vidas = vidas;
    }
}

 