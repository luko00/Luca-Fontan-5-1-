import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;
import java.awt.Image;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.List;

public class Jugador {
    private JLabel player1; // Cambiado de JPanel a JLabel
    private int playerSpeed = 10;
    private boolean player1Left = false;
    private boolean player1Right = false;
    private List<JPanel> balas;
    private Timer disparoDelayTimer;
    private boolean canShoot = true; // Indicates if the player can shoot
    private Enemigos2 enemigos;

    public Jugador(JFrame frame, Enemigos2 enemigos) {
        this.balas = new ArrayList<>();
        this.enemigos = enemigos;
        initialize(frame);
    }

    private void initialize(JFrame frame) {
        // Cargar la imagen
        ImageIcon icon = new ImageIcon("nave.png"); 
        Image image = icon.getImage();
        
        // Redimensionar la imagen
        Image resizedImage = image.getScaledInstance(50, 50, Image.SCALE_SMOOTH); // Ajusta el tama�o seg�n sea necesario
        
        // Usar la imagen redimensionada en el JLabel
        player1 = new JLabel(new ImageIcon(resizedImage));
        player1.setBounds(195, 586, 50, 50); // Ajusta el tama�o seg�n la imagen
        frame.getContentPane().add(player1);

        frame.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {}
            @Override
            public void keyPressed(KeyEvent e) {
                handleKeyPress(e);
            }
            @Override
            public void keyReleased(KeyEvent e) {
                handleKeyRelease(e);
            }
        });

        Timer playerMovementTimer = new Timer(16, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                movePlayers(frame);
                updateBalas();
            }
        });
        playerMovementTimer.start();
    }

    private void handleKeyPress(KeyEvent e) {
        int key = e.getKeyCode();
        if (key == KeyEvent.VK_LEFT) {
            player1Left = true;
        } else if (key == KeyEvent.VK_RIGHT) {
            player1Right = true;
        } else if (key == KeyEvent.VK_SPACE && canShoot) {
            shoot();
        }
    }

    private void handleKeyRelease(KeyEvent e) {
        int key = e.getKeyCode();
        if (key == KeyEvent.VK_LEFT) {
            player1Left = false;
        } else if (key == KeyEvent.VK_RIGHT) {
            player1Right = false;
        }
    }

    private void movePlayers(JFrame frame) {
        int x = player1.getX();
        int y = player1.getY();
        int frameWidth = frame.getWidth();
        int playerWidth = player1.getWidth();

        if (player1Left && x > 0) {
            player1.setLocation(Math.max(x - playerSpeed, 0), y);
        }
        if (player1Right && x < frameWidth - playerWidth) {
            player1.setLocation(Math.min(x + playerSpeed, frameWidth - playerWidth), y);
        }
    }

    private void shoot() {
        int x = player1.getX() + (player1.getWidth() / 2) - 2; // Position the bullet center
        int y = player1.getY() - 10; // Shoot above the player

        JPanel nuevaBala = new JPanel();
        nuevaBala.setBackground(Color.RED);
        nuevaBala.setOpaque(true);
        nuevaBala.setBounds(x, y, 5, 10); // Tama�o de la bala
        
        player1.getParent().add(nuevaBala);
        balas.add(nuevaBala);

        // Disable shooting and start timer to re-enable shooting after 0.5 seconds
        canShoot = false;
        disparoDelayTimer = new Timer(500, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                canShoot = true;
                disparoDelayTimer.stop();
            }
        });
        disparoDelayTimer.start();
    }

    private void updateBalas() {
        List<JPanel> toRemoveBala = new ArrayList<>();
        for (JPanel bala : balas) {
            bala.setLocation(bala.getX(), bala.getY() - 15); // Move bullet up
            if (bala.getY() < 0) {
                toRemoveBala.add(bala);
                player1.getParent().remove(bala);
            } else if (checkCollision(bala)) {
                toRemoveBala.add(bala);
                player1.getParent().remove(bala);
            }
        }
        balas.removeAll(toRemoveBala);
    }

    private boolean checkCollision(JPanel bala) {
        Rectangle bulletBounds = bala.getBounds();
        for (int row = 0; row < enemigos.getNumRows(); row++) {
            for (int col = 0; col < enemigos.getNumEnemiesPerRow(); col++) {
                JPanel enemigo = enemigos.getEnemy(row, col);
                if (enemigo != null) {
                    Rectangle enemyBounds = enemigo.getBounds();
                    if (bulletBounds.intersects(enemyBounds)) {
                        enemigos.removeEnemy(row, col); // Remove enemy on collision
                        return true;
                    }
                }
            }
        }
        return false;
    }
}
